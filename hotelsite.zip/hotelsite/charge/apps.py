from django.apps import AppConfig


class ChargeConfig(AppConfig):
    name = 'charge'
