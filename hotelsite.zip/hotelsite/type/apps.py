from django.apps import AppConfig


class TypeConfig(AppConfig):
    name = 'type'
