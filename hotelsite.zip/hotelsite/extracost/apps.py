from django.apps import AppConfig


class ExtracostConfig(AppConfig):
    name = 'extracost'
