from django.apps import AppConfig


class GuestcarConfig(AppConfig):
    name = 'guestcar'
